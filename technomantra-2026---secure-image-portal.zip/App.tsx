
import React, { useState, useCallback } from 'react';
import { Button } from './components/Button';
import { Input } from './components/Input';
import { uploadToTechnomantra } from './services/supabase';
import { generateAIGreeting } from './services/geminiService';
import { UserData, UploadState } from './types';

const App: React.FC = () => {
  const [formData, setFormData] = useState<UserData>({
    name: '',
    feedback: '',
    file: null,
  });

  const [uploadStatus, setUploadStatus] = useState<UploadState>({
    isUploading: false,
    progress: 0,
    error: null,
    success: false,
    publicUrl: null,
  });

  const [aiMessage, setAiMessage] = useState<string>('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({ ...prev, file: e.target.files![0] }));
    }
  };

  const handleUpload = async () => {
    if (!formData.name || !formData.file) {
      setUploadStatus(prev => ({ ...prev, error: "Name and image are required." }));
      return;
    }

    setUploadStatus({
      isUploading: true,
      progress: 0,
      error: null,
      success: false,
      publicUrl: null,
    });

    try {
      // 1. Upload to Supabase
      const result = await uploadToTechnomantra(formData.name, formData.file);
      
      // 2. Generate AI Greeting in parallel
      const greeting = await generateAIGreeting(formData.name, formData.feedback);
      setAiMessage(greeting);

      setUploadStatus({
        isUploading: false,
        progress: 100,
        error: null,
        success: true,
        publicUrl: result.publicUrl,
      });

      // Clear form except file (to show preview in modal)
      setFormData(prev => ({ ...prev, name: '', feedback: '' }));

    } catch (err: any) {
      setUploadStatus(prev => ({
        ...prev,
        isUploading: false,
        error: err.message || "An unexpected error occurred."
      }));
    }
  };

  const closeModal = () => {
    setUploadStatus(prev => ({ ...prev, success: false }));
    setFormData(prev => ({ ...prev, file: null }));
  };

  return (
    <div className="min-h-screen grid-bg flex flex-col items-center justify-center p-6 md:p-12 relative">
      {/* Decorative Orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-sky-500/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
        
        {/* Left: Hero Content */}
        <div className="space-y-8 text-center lg:text-left">
          <div className="inline-flex items-center px-3 py-1 rounded-full border border-sky-500/30 bg-sky-500/5 text-sky-400 text-xs font-bold uppercase tracking-widest mb-4">
            Visionary Portal v2.0
          </div>
          <h1 className="text-5xl md:text-7xl font-bold leading-tight">
            Technomantra <br />
            <span className="gradient-text">2026</span>
          </h1>
          <p className="text-slate-400 text-lg md:text-xl max-w-md mx-auto lg:mx-0 leading-relaxed">
            Archive your digital signature for the next epoch of technology. 
            Secure, decentralized, and AI-powered.
          </p>
          
          <div className="flex flex-wrap gap-6 justify-center lg:justify-start pt-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-slate-500 text-sm">Supabase Secure</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-sky-500 animate-pulse"></div>
              <span className="text-slate-500 text-sm">Gemini AI Enhanced</span>
            </div>
          </div>
        </div>

        {/* Right: Upload Form Card */}
        <div className="glass rounded-[2rem] p-8 md:p-10 shadow-2xl space-y-6 relative group">
          {/* Neon Border Effect */}
          <div className="absolute inset-0 rounded-[2rem] border border-white/5 group-hover:border-sky-500/20 transition-colors pointer-events-none"></div>
          
          <Input 
            label="Transmitter Name" 
            placeholder="Identity designation..." 
            value={formData.name}
            onChange={(e) => setFormData(p => ({ ...p, name: e.target.value }))}
          />

          <div className="space-y-2">
            <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider">
              Visual Data (Image)
            </label>
            <div className={`relative flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-6 transition-all ${formData.file ? 'border-emerald-500/50 bg-emerald-500/5' : 'border-slate-800 hover:border-sky-500/50 bg-slate-950/30'}`}>
              <input 
                type="file" 
                accept="image/*"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                onChange={handleFileChange}
              />
              <div className="text-center">
                {formData.file ? (
                  <div className="flex flex-col items-center">
                    <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mb-2">
                      <svg className="w-8 h-8 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <p className="text-emerald-400 font-medium text-sm truncate max-w-[200px]">{formData.file.name}</p>
                    <button onClick={(e) => { e.stopPropagation(); setFormData(p => ({ ...p, file: null })); }} className="text-xs text-slate-500 mt-2 hover:text-slate-300">Change File</button>
                  </div>
                ) : (
                  <>
                    <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <svg className="w-8 h-8 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                      </svg>
                    </div>
                    <p className="text-slate-300 font-medium">Click or Drag Image</p>
                    <p className="text-slate-500 text-xs mt-1">PNG, JPG, WEBP (Max 10MB)</p>
                  </>
                )}
              </div>
            </div>
          </div>

          <Input 
            label="Transmission Feedback" 
            placeholder="Share your technical vision..." 
            isTextArea
            value={formData.feedback}
            onChange={(e) => setFormData(p => ({ ...p, feedback: e.target.value }))}
          />

          {uploadStatus.error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-sm p-4 rounded-xl flex items-center gap-3">
              <svg className="w-5 h-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {uploadStatus.error}
            </div>
          )}

          <Button 
            className="w-full h-14 text-lg" 
            isLoading={uploadStatus.isUploading}
            onClick={handleUpload}
          >
            Initiate Secure Upload
          </Button>
        </div>
      </div>

      {/* Footer Branding */}
      <div className="mt-12 text-slate-600 text-sm font-medium tracking-widest uppercase opacity-50">
        Engineered for the 2026 Visionary Collective
      </div>

      {/* Success Modal */}
      {uploadStatus.success && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-md transition-opacity">
          <div className="glass max-w-md w-full rounded-[2.5rem] p-10 shadow-2xl text-center space-y-6 animate-in fade-in zoom-in duration-300">
            <div className="w-24 h-24 bg-gradient-to-tr from-sky-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-sky-500/20">
              <svg className="w-12 h-12 text-slate-900" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            
            <h2 className="text-3xl font-bold">Transmission Complete</h2>
            
            <div className="space-y-2">
              <p className="text-slate-400 text-sm uppercase tracking-tighter">AI Analysis Protocol:</p>
              <p className="text-emerald-400 font-medium italic">"{aiMessage}"</p>
            </div>

            {uploadStatus.publicUrl && (
              <div className="rounded-2xl overflow-hidden border border-slate-800 bg-slate-900/50 p-2">
                <img 
                  src={uploadStatus.publicUrl} 
                  alt="Uploaded Visual" 
                  className="w-full h-48 object-cover rounded-xl"
                />
              </div>
            )}

            <Button variant="primary" className="w-full" onClick={closeModal}>
              Acknowledge & Close
            </Button>
          </div>
        </div>
      )}

      {/* Toast Notification (Simple Implementation) */}
      <div className={`fixed bottom-8 right-8 z-[200] flex items-center gap-3 bg-slate-900 border border-emerald-500/30 px-6 py-4 rounded-2xl shadow-2xl transition-all duration-500 transform ${uploadStatus.success ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0 pointer-events-none'}`}>
        <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
          <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
        </div>
        <div className="text-sm font-semibold text-slate-200">
          Neural Uplink Successful 🚀
        </div>
      </div>
    </div>
  );
};

export default App;
