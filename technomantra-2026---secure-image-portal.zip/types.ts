
export interface UploadState {
  isUploading: boolean;
  progress: number;
  error: string | null;
  success: boolean;
  publicUrl: string | null;
}

export interface UserData {
  name: string;
  feedback: string;
  file: File | null;
}

export interface GeminiResponse {
  message: string;
}
