
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateAIGreeting = async (name: string, feedback: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `
        The user "${name}" has just uploaded an image to the Technomantra 2026 event portal.
        Their feedback was: "${feedback}".
        Generate a very short (1 sentence), futuristic, and inspiring "thank you" message for them. 
        Keep it tech-focused and cool.
      `,
      config: {
        temperature: 0.8,
        topP: 0.95,
      }
    });

    return response.text || "Welcome to the future of technology, visionary.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Your vision has been successfully integrated into the Technomantra grid.";
  }
};
