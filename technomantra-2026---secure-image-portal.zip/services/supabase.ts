
// Using the client's provided credentials as requested
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

const SUPABASE_URL = "https://worcmjutlantjutpdsjq.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_vK-bQ1JYqzhN4K6WFUP73Q_WiBeVfxu";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export const uploadToTechnomantra = async (name: string, file: File) => {
  const ext = file.name.split('.').pop();
  const filePath = `${name.replace(/\s+/g, '_')}_${Date.now()}.${ext}`;

  const { data, error } = await supabase.storage
    .from("technomantra")
    .upload(filePath, file);

  if (error) throw error;

  const { data: urlData } = supabase.storage
    .from("technomantra")
    .getPublicUrl(filePath);

  return {
    path: data.path,
    publicUrl: urlData.publicUrl
  };
};
